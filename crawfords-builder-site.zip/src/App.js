
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload } from "lucide-react";
import { motion } from "framer-motion";

export default function BuilderHomePage() {
  const [photos, setPhotos] = useState([]);

  const handlePhotoUpload = (e) => {
    const files = Array.from(e.target.files);
    const newPhotos = files.map((file) => URL.createObjectURL(file));
    setPhotos([...photos, ...newPhotos]);
  };

  return (
    <div className="min-h-screen bg-gray-100 text-gray-900 p-6">
      <header className="text-center mb-10">
        <img
          src="/Crawfords Building Logo 2.JPG"
          alt="Crawfords Building Logo"
          className="mx-auto mb-6 w-72"
        />
        <h1 className="text-5xl font-bold text-gray-900">Temora Prestige Homes</h1>
        <p className="text-lg text-gray-700 mt-4">
          Crafting luxury homes in Temora, NSW — tailored design, impeccable finishes.
        </p>
      </header>

      <section className="grid md:grid-cols-2 gap-6 items-center mb-16">
        <div>
          <h2 className="text-3xl font-semibold text-orange-600 mb-4">About Us</h2>
          <p className="text-gray-800 text-lg leading-relaxed">
            With a reputation for premium quality, we specialize in custom residential
            builds that balance timeless elegance with modern innovation. Our close-knit
            team of expert craftsmen ensures your home is built to the highest standard.
          </p>
        </div>
        <motion.img
          src="https://images.unsplash.com/photo-1570129477492-45c003edd2be"
          alt="Luxury Home Example"
          className="rounded-2xl shadow-lg"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        />
      </section>

      <section className="mb-16">
        <h2 className="text-3xl font-semibold text-orange-600 mb-6">Project Gallery</h2>
        <input
          type="file"
          multiple
          accept="image/*"
          onChange={handlePhotoUpload}
          className="mb-4"
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {photos.map((src, idx) => (
            <Card key={idx} className="overflow-hidden">
              <CardContent className="p-0">
                <img src={src} alt={`Project ${idx + 1}`} className="w-full h-60 object-cover" />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="mb-16">
        <h2 className="text-3xl font-semibold text-orange-600 mb-4 text-center">Client Testimonials</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="p-6 bg-white shadow-md rounded-2xl">
            <CardContent>
              <p className="text-gray-800 italic mb-4">
                “Crawfords Building brought our dream to life. The craftsmanship and attention to detail exceeded all expectations.”
              </p>
              <p className="text-sm font-semibold text-gray-600">— Sarah & David, Temora</p>
            </CardContent>
          </Card>
          <Card className="p-6 bg-white shadow-md rounded-2xl">
            <CardContent>
              <p className="text-gray-800 italic mb-4">
                “Professional, reliable, and truly passionate about quality. We couldn’t be happier with the outcome.”
              </p>
              <p className="text-sm font-semibold text-gray-600">— John M., Regional NSW</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="text-center">
        <h2 className="text-3xl font-semibold text-orange-600 mb-4">Start Your Dream Build</h2>
        <p className="text-lg text-gray-700 mb-6">
          Let’s design and build a home that’s truly yours. Get in touch for a consultation.
        </p>
        <Button className="text-lg px-6 py-3 rounded-2xl bg-orange-600 text-white hover:bg-orange-500">
          Contact Us
        </Button>
      </section>
    </div>
  );
}
